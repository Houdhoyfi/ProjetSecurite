import java.util.Scanner;

public class Vigenere {
    private static Scanner scan;
    private static String message;
    private static String cle;
    private static String cleMap;
    private static String messageChiffre;
    private static String messageDechiffre;
    

    public static void main(String[] args){

        scan = new Scanner(System.in); //Création de l'object scanner pour nos saisis
        System.out.println("Chiffre Vigenere ");
        System.out.print("1. CHIFFREMENT ou 2 DECHIFFREREMENT ");
        int choix = scan.nextInt();
        scan.nextLine();

        switch(choix){
            case 1:
                System.out.println("***CHIFFREMENT***");
                Chiffrement(message, cleMap,cle);
                break;

            case 2:
                System.out.println("***DECHIFFREMENT***");
                Dechiffrement(message, cleMap, cle);
                break;

            default:
                System.out.println("Caractère invalid ");
                System.exit(0);
        }

    }

    private static void Chiffrement(String message, String cleMap, String cle) {
        int[][] table = Tableau();     
        //Lecture du message saisi
        System.out.print("Entrez le message en clair : ");
        message = scan.nextLine(); 
        message = message.toUpperCase();
        //Lecture de la clé saisie
        System.out.print("Entrez la clé de chiffrement: ");
        cle = scan.next(); 
        scan.nextLine();
        cle = cle.toUpperCase();
        String keyMap = "";
        for (int i = 0, j = 0; i < message.length(); i++) {
            
            if(message.charAt(i) == (char)32){
                // Pour eviter de prendre en compte les espaces
                keyMap += (char)32;
            } else {
                //Associe les lettres de la clé avec le message
                if(j < cle.length()){
                    keyMap += cle.charAt(j);
                    j++;
                } else {
                    //Recommence au début de la clé une fois arrivé à la fin
                    j = 0;
                    keyMap += cle.charAt(j);
                    j++; //Sans l'incrémentation, l'association sur la première lettre de  la clé sera fait deux fois

                }
            } 
        }
        cleMap = keyMap;
        messageChiffre = "";
        for (int i = 0; i < message.length(); i++) {
            if(message.charAt(i) == (char)32 && cleMap.charAt(i) == (char)32){
                messageChiffre += " ";
            } else {
                //Remplace par une lettre l'élément à la position [i][j] dans notre tableau
                messageChiffre += (char)table[(int)message.charAt(i)-65][(int)cleMap.charAt(i)-65];
            }
        }

        System.out.println("Message chiffré: " + messageChiffre);
    }


    private static void Dechiffrement(String message, String cleMap, String cle) {
        //Lecture du message saisi
        System.out.print("Entrez le message chiffré : ");
        message = scan.nextLine(); 
        message = message.toUpperCase();
        //Lecture de la clé saisie
        System.out.print("Entrez la clé de déchiffrement: ");
        cle = scan.next(); 
        scan.nextLine();
        cle = cle.toUpperCase();
        String keyMap = "";
        for (int i = 0, j = 0; i < message.length(); i++) {
            
            if(message.charAt(i) == (char)32){
                // Pour eviter de prendre en compte les espaces
                keyMap += (char)32;
            } else {
                //Associe les lettres de la clé avec le message
                if(j < cle.length()){
                    keyMap += cle.charAt(j);
                    j++;
                } else {
                    // Recommence au début de la clé une fois arrivé à la fin
                    j = 0;
                    keyMap += cle.charAt(j);
                    j++; //Sans l'incrémentation, l'association  la première lettre de  la clé sera fait deux fois

                }
            } 
        }
        cleMap = keyMap;
        messageDechiffre = "";
        for (int i = 0; i < message.length(); i++) {
            if(message.charAt(i) == (char)32 && cleMap.charAt(i) == (char)32){
                messageDechiffre += " ";
            } else {
                messageDechiffre += (char)(65 + itrCount((int)cleMap.charAt(i), (int)message.charAt(i)));
            }
        }

        System.out.println("Message déchiffré: " + messageDechiffre);
       
    }

    private static int itrCount(int key, int msg) {
        //Retourne le nombre de la lettre de la clé qu’elle utilise pour atteindre la lettre de chiffrement
        //Ce nombre est ensuite utilisé pour calculer le décryptage de la lettre chiffrée dans le message
        int counter = 0;
        String result = "";
        for (int i = 0; i < 26; i++) {
            if(key+i > 90){  //ASCII de Z        
                result += (char)(key+(i-26));
            } else {
                result += (char)(key+i);
            }
        }
        //compte depuis la lettre de la clé jusqu'à celle du chiffrement dans le tableau
        for (int i = 0; i < result.length(); i++) {
            if(result.charAt(i) == msg){
                break;
            } else {
                counter++;
            }
        }
        return counter;
    }   

    //Création de la table de Vigenère 26x26
    private static int[][] Tableau() {
        int[][] tableArr = new int[26][26];
        for (int i = 0; i < 26; i++) {
            for (int j = 0; j < 26; j++) {
                int temp;
                if((i+65)+j > 90){
                    temp = ((i+65)+j) -26;
                    tableArr[i][j] = temp;
                } else {
                    temp = (i+65)+j;
                    tableArr[i][j] = temp;
                }
            }
        }

       
        return tableArr;
    }
    
}
