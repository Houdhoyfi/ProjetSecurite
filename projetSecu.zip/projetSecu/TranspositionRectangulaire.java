import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
public class TranspositionRectangulaire{
    public static char CleTrie[];
    public static int PosCleTrie[];
    public static void main(String args[]){

        Scanner scan = new Scanner(System.in);
        String ligne = System.getProperty("line.separator");
        scan.useDelimiter(ligne);
        //afficher au lancement du programme
        System.out.print("1- Chiffrement : ");
        int option = scan.nextInt();
        switch (option) {
            case 1:
                System.out.print("Entrer le texte à chiffrer : (exemple : JESUISENITALIE ) : ");
                String texte = scan.next().toUpperCase().replace(" ", "");;//texte contient le texte qu'on doit chiffré

                System.out.print("Entrer la cle : (exemple : IBMATH ) :");
                String cle =  scan.next();//on récupère la valeur de a saisi 

                //on applique le chiffrement avec les paramètres correspondant
                System.out.println(Chiffrement(texte,cle));
                break;

            default:
                System.out.println("Caractère invalide : choisir 1 ou 2 : ");
                System.exit(0);
                //break;
                
        }
    }

    //Chiffrement 
    static String Chiffrement(String mssg, String cle) {

        //tableau qui va contenir l'index de chaque lettre de la clé 
        PosCleTrie = new int[cle.length()];

        //converti cle string en chaine de carac
        CleTrie = cle.toCharArray();
        char orginalKey[] = cle.toCharArray();

        // Tri du tableau de la clé sélectionnée
        int min, i, j;
        char temp;
        for (i = 0; i < cle.length(); i++) {
            min = i;
            for (j = i; j < cle.length(); j++) {
                if (CleTrie[min] > CleTrie[j]) { 
                    min = j;
                }
            }
            if (min != i) {
                temp = CleTrie [i];
                CleTrie [i] = CleTrie [min];
                CleTrie [min] = temp;
            }
        }

        // Remplir la position du tableau par ordre alphabétique
        for (i = 0; i < cle.length(); i++) {
            for (j = 0; j < cle.length(); j++) {
                if (orginalKey[i] == CleTrie[j]){
                    PosCleTrie[i] = j;
                }
            }
        }

        //insertion du message dans la matrice
        int ligne = (mssg.length())/(cle.length())+1;
        int colonne = cle.length();
        char [][] matrice = new char[ligne][colonne];
        int  coltemporaire = -1;
        ligne = 0;
        for (i = 0; i < mssg.length(); i++) {
            coltemporaire++;
            if (i < mssg.length()) {
                if (coltemporaire == (colonne)) {
                    ligne++;
                    coltemporaire = 0;
                }
                //System.out.println("row : "+mssg.charAt(i));
                matrice[ligne][coltemporaire] = mssg.charAt(i);
            }
        }

        //parcours du tableau pour ensuite affecter le résultat dans la varible res
        int  k;
        String res = "";
        for (i = 0; i < cle.length(); i++) {
            for (k = 0; k < cle.length(); k++) {
                if (i == PosCleTrie[k]) {
                    break;
                }
            }
            for (j = 0; j < 4; j++) {
                //System.out.print(matrice[j][k]);
                res = res+matrice[j][k];
            }
            System.out.println();
        }
        System.out.println("message chiffré : ");
        return res; 
    } //fin chiffrement 

}
