import java.util.Scanner;

public class DES_Simplifie {
    public static void main(String []args){
        Scanner scan = new Scanner(System.in);
        String line = System.getProperty("line.separator");
        scan.useDelimiter(line);
        System.out.println("DES simplifié  : ");
        System.out.println();
        System.out.print("Entrer le texte à chiffrer en hexadécimal:  (exemple : 3c4d ) : ");
        String texte = scan.next();//texte contient le texte qu'on doit chiffré et on élimine les espaces
        System.out.print("Enter la clé en hexadécimal : (exemple : 1a2b ) : ");
        String a =  scan.next();//on récupère la valeur de a saisi 
        System.out.println(Chiffrement(texte,a));


    }

    static String Chiffrement(String texte, String cle) {
    //texte="3c4d";cle="1a2b";
    String L0="";
    String R0="";String EXP="";String PC2="";String PB="";
    String valChiffreHexa="";

    String [] enteteSboxVertic = {"00","01","10","11"};
    String [] enteteSboxHozont = {"0000","0001","0010","0011","0100","0101","0110","0111","1000","1001","1010","1011","1100","1101","1110","1111"}; 
    int[][]  S1= {{14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7}, 
                    {0,15,7,4,14,2,13,1,10,6,12,11,9,5,3},
                    {4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0},
                    {15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13} 
                };

    int [][] S2 = {{15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10},
                    {3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5},
                    {0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15},
                    {13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9} 
                };

    //boucle exécuter 16 fois le DES simplifié 
    for(int z=1;z<17;z++){

        //on converti le message hexadécimal en int ensuite en binaire
        Integer valeur=Integer.valueOf(String.valueOf(texte),16);
        String BloctexteBin=Integer.toBinaryString(valeur.intValue());
    
        //on vérifie si la taille du mot en binaire est < à 16 , on rajoute des 0 devant 
        if(BloctexteBin.length()<16){
            int resteZero = 16-(BloctexteBin.length());
            for (int i=0;i<resteZero;i++){
                BloctexteBin = "0"+BloctexteBin;
            }
        }

        int bit=0;
        int[][] NumeroLettre = {{16,14,12,10,8,6,4,2}, {15,13,11,9,7,5,3,1} };
        //calcul du bloc  L0
        L0="";
        for (int i = 0; i < 1; ++i) {
            for(int j = 0; j < NumeroLettre[i].length; ++j) {
                bit= (NumeroLettre[i][j])-1;
                L0 = L0 + BloctexteBin.charAt(bit);
            }
        }
        //calcul du bloc R0
        R0="";
        for (int i = 1; i < 2; ++i) {
            for(int j = 0; j < NumeroLettre[i].length; ++j) {
                bit= (NumeroLettre[i][j])-1;
                R0 = R0 + BloctexteBin.charAt(bit);
            }        
        }

        //Appliquer Expansion 2 sur RO
        int bitExpansion=0;
        EXP = "";
        int[][] expansionE = {{8,1,2,3,4,5}, {4,5,6,7,8,1} };
        for (int i = 0;  i< expansionE.length; ++i) {
            for(int j = 0; j < expansionE[i].length; ++j) {
                bitExpansion= (expansionE[i][j])-1;
                EXP = EXP + R0.charAt(bitExpansion);
            }
        }
        //calcule du sous clé 
        //on converti la clé hexadécimal en int ensuite en binaire
        Integer valeurcle=Integer.valueOf(String.valueOf(cle),16);
        String BloccleBin=Integer.toBinaryString(valeurcle.intValue());
        //on vérifie si la taille de la clé en binaire est < à 16 , on rajoute des 0 devant 
        if(BloccleBin.length()<16){
            for (int i=0;i<18-(BloccleBin.length());i++){
                BloccleBin = "0"+BloccleBin;
            }
        }
        String moitieGauche= "";
        String moitieDroite= "";
        //Tableau permutation PC1 simple 

        int[][] PermPC1 = {{14,12,10,6,4,2,1}, {15,13,11,9,7,5,3} };
        int bitPermPC1=0;
        //on fait la permutation a gauche 
        for (int i = 0;  i< 1; ++i) {
            for(int j = 0; j < PermPC1[i].length; ++j) {
                bitPermPC1= (PermPC1[i][j])-1;
                moitieGauche = moitieGauche + BloccleBin.charAt(bitPermPC1);
            }
        }
        //on fait la permutation a droite 
        int bitt=0;
        for (int i = 1; i < 2; ++i) {
            for(int j = 0; j < PermPC1[i].length; ++j) {
                bitt= (PermPC1[i][j])-1;
                moitieDroite = moitieDroite + BloccleBin.charAt(bitt);
            }
        }
        //rotation gauche
        String moitieGaucheRot= "";
        for(int i=1;i<moitieGauche.length();i++){
            moitieGaucheRot= moitieGaucheRot+moitieGauche.charAt(i);
        }
        moitieGaucheRot = moitieGaucheRot+moitieGauche.charAt(0);
        //rotation droite 
        String moitieDroiteRot= "";    
        for(int i=1;i<moitieDroite.length();i++){
            moitieDroiteRot= moitieDroiteRot+moitieDroite.charAt(i);
        }
        moitieDroiteRot = moitieDroiteRot+moitieDroite.charAt(0);

        //rotation gauche final du bloc 
        String rotationGauche = moitieGaucheRot+moitieDroiteRot;

       //Permutation PC 2
       PC2="";
       int bitPC2=0;
       int[][]  PermutationPC2= {{10,8,1,6,12,4}, {13,3,11,5,9,2} };
       for (int i = 0;  i< PermutationPC2.length; ++i) {
            for(int j = 0; j < PermutationPC2[i].length; ++j) {
                bitPC2= (PermutationPC2[i][j])-1;
                PC2= PC2 + rotationGauche.charAt(bitPC2);
            }
        } 
    
        //Calculer A = E(R0) ⊕ K1, où ⊕ est le ou exclusif (xor).
        int pc2 = Integer.parseInt(PC2,2); //on met PC2 en int
        int exp = Integer.parseInt(EXP,2);//on met EXP en int
        //ou exclusif de pc2 et expansion en int 
        int OuexInt = (pc2^exp);
        //ou exclusif de pc2 et expansion converti en binaire
        String OuExBinaire = Integer.toBinaryString(OuexInt);
        //on vérifie si le ou exlusif fait bien 12 bit sinon on rajoute des zéros au début 
        if(OuExBinaire.length()<12){
            int resteZero = 12-(OuExBinaire.length());
            for (int i=0;i<resteZero;i++){
                OuExBinaire = "0"+OuExBinaire;
            }
        }

        //B1 Valeur fourni la S-Box S1 sur le premier bloc et B2 par S2 sur le second bloc  
        String B1 = "";String B2 = "";
        for (int i=0;i<OuExBinaire.length()/2;i++){
            B1 = B1+OuExBinaire.charAt(i);
        }

        for (int i=OuExBinaire.length()/2;i<OuExBinaire.length();i++){
            B2 = B2+OuExBinaire.charAt(i);
        }

        
        int S1B1 =0;int S1B2 =0;
        //on prend les extrémité de B1 et B2
        char extremB1_1 =B1.charAt(0);char extremB1_2 =B1.charAt(5);
        char extremB2_1 =B2.charAt(0);char extremB2_2 =B2.charAt(5);
        //on prend le milieu de b1 et b2 
        String milieuB1 =String.valueOf(extremB1_1)+String.valueOf(extremB1_2);
        String milieuB2 =String.valueOf(extremB2_1)+String.valueOf(extremB2_2);

        //S1B2
        int valVerti=0;
        //on regarde les valeurs sur enteteSboxVertic de milieu B1
        for(int i=0;i<enteteSboxVertic.length;i++){
            if(milieuB1.equals(enteteSboxVertic[i])){
                valVerti=i;
            }
        }
    
        int valHoriz=0;
        //on regarde les valeurs sur enteteSboxHozont de  B1
        for(int i=0;i<enteteSboxHozont.length;i++){
            if(B1.substring(1,5).equals(enteteSboxHozont[i])){
                valHoriz = i;
            }
        }
        // on maintenat S1B1
        S1B1 = S1[valVerti][valHoriz];

        //S2B2
        int valVerti2=0;
        for(int i=0;i<enteteSboxVertic.length;i++){
            if(milieuB2.equals(enteteSboxVertic[i])){
                valVerti2=i;
            }
        }
    
        int valHoriz2=0;
        for(int i=0;i<enteteSboxHozont.length;i++){
            if(B2.substring(1,5).equals(enteteSboxHozont[i])){
                valHoriz2 = i;
            }
        }
        // on maintenat S1B2
        S1B2 = S2[valVerti2][valHoriz2];

        String B = "";String bgauche="";String bdroite="";
        bgauche = Integer.toBinaryString(S1B1);
        bdroite = Integer.toBinaryString(S1B2);
        //on regarde si on a bien 4 bit sinon on rajoute des 0 au début 
        if(bgauche.length()<4){
            int resteZero = 4-(bgauche.length());
            for (int i=0;i<resteZero;i++){
                bgauche = "0"+bgauche;
            }
        }
        //on regarde si on a bien 4 bit sinon on rajoute des 0 au début
        if(bdroite.length()<4){
            int resteZero = 4-(bdroite.length());
            for (int i=0;i<resteZero;i++){
                bdroite = "0"+bdroite;
                }
        }
        //Concaténer les résultats obtenus à la question (5) ci-dessus 
        //pour obtenir la suite B de 8 bits.
        B=bgauche+bdroite;
        //permutation final 
        int bitPB=0;
        int[]  Permfinal= {8,4,2,6,1,5,3,7};
        PB ="";
        for(int j = 0; j < Permfinal.length; ++j) {
            bitPB= (Permfinal[j])-1;
            PB= PB+ B.charAt(bitPB);
        }

        //Calculer R1 = P(B) ⊕ L0.
        int pb = Integer.parseInt(PB,2);
        int lo = Integer.parseInt(L0,2);
        int ouexClu = (pb^lo);
        String R1="";
        //on regarde si R1 fait bien 8 bit 
        R1 = Integer.toBinaryString(ouexClu);
        if(R1.length()<8){
            int resteZero = 8-(R1.length());
            for (int i=0;i<resteZero;i++){
                R1 = "0"+R1;
            }
        }

        String chiffreFinal = "";
        chiffreFinal = R0+R1;
        //on passe le chiffreFinal à BloctexteBin en débur de boucle 
        BloctexteBin = chiffreFinal;
        int chiffreFinalInt = Integer.parseInt(chiffreFinal,2);
        //on converti notre chiffre en Hexadécimal 
        valChiffreHexa = Integer.toHexString(chiffreFinalInt);

        texte=valChiffreHexa;
        }
        System.out.print("texte chiffré  : ");
        String res = valChiffreHexa;
        return res;
        

    }

}
