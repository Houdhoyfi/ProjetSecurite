import java.util.ArrayList;
import java.util.Scanner;

public class Delastelle {
    public static void main(String args[]){
        Scanner scan = new Scanner(System.in);
        String line = System.getProperty("line.separator");
        scan.useDelimiter(line);
        //afficher au lancement du programme
        System.out.println("Chiffre de Delastelle : ");
        System.out.println();
        System.out.print("1- Chiffrement ou  2-Déchiffrement : ");
        int option = scan.nextInt();
        switch (option) {
            case 1:
                System.out.print("Entrer le texte à chiffrer : ");
                String texte = scan.next().toUpperCase().replace(" ", "");;//texte contient la phrase qu'on doit chiffrer

                //on applique le chiffrement avec texte
                System.out.println(Chiffrement(texte));
                break;
            case 2:
                System.out.print("Entrer le texte à déchiffrer :");
                texte = scan.next().toUpperCase().replace(" ", "");;//texte contient la phrase qu'on doit Déchiffrer

                //on applique le chiffrement avec texte
                System.out.println(Dechiffrement(texte));
                break;
            default:
                System.out.println("Caractère invalide : choisir 1 ou 2 : ");
                System.exit(0);
                //break;
                
        }
    }
    //Chiffrement 
    static String Chiffrement(String texte) {

        //coordonnee est la liste des coordonnee x et y
        ArrayList<Integer> coordonnee = new ArrayList<Integer>();
        String Ensemblecoordonne = " ";
        String xtest = "";
        String ytest="";
        String res = "";

        //le tableau dit carré de polybe 6*6
        char[][] tableau = {{'V','B','K','U','A','9'}, {'C','L','X','R','D','8'},
                            {'M','Y','S','F','N','7'},{'Z','O','G','P','I','6'},
                            {'H','Q','E','W','T','5'},{'0','1','2','3','4'},
                            };
        //on regarde si le texte n'est pas un multiple de 11 on rajoute 'X'
        while((texte.length()%11) !=0){
            texte=texte+'X';
        }
       // System.out.println("taille texte apres while : "+texte.length());
       // System.out.println("texte apres while : "+texte);

        //calcule des coordonnées avec le tableau dit de carré de polybe 6*6 
        for(int i=0;i<texte.length();i++){
            char carac = texte.charAt(i);
            for(int a=0;a<tableau.length;a++){
                for(int z=0;z<tableau[a].length;z++){
                    if(carac==tableau[a][z]){
                        coordonnee.add(a+1);
                        coordonnee.add(z+1);
                        //System.out.println("lettre : "+carac+ " ligne : "+(a+1)+" colonne : "+(z+1));
                    }
                }
            }
        }

        //x1 coordonnee x de la lettre
        int x1;
        //y1 coordonnee y de la lettre
        int y1;
        //blocOnze permet de découper les mots par bloc de 11
        int blocOnze=20;
        //on boucle sur la liste des coordonnee avec un pas de 2
        for(int i=0;i<coordonnee.size();i=i+2){
            //x1 coordonnee x de la lettre
            x1 = coordonnee.get(i);
            //y1 coordonnee y de la lettre
            y1 = coordonnee.get(i+1);
            //Ensemble des coordonnée x dans le bloc de 11
            xtest= xtest+x1;
            //Ensemble des coordonnée y dans le bloc de 11
            ytest= ytest+y1;
            if(i == blocOnze){//lorsque on a notre bloc de 11 x et y , on ajoute les coordonnée dans Ensemblecoordonne
                //Ensemblecoordonne contient les coordonnée x et y de 11 bloc 
                Ensemblecoordonne=Ensemblecoordonne+xtest+ytest;
                //blocOnze est égal au prochain bloc de 11
                blocOnze=blocOnze+22;
                //on réinitialise xtest et ytest 
                xtest="";
                ytest="";
            }
        }

        System.out.println("Texte chiffré : ");
        // on parcours Ensemblecoordonnee et ensuite on affiche en fonction du tableau de polybe 
        for(int i =1;i<Ensemblecoordonne.length();i=i+2){
            int x = Character.getNumericValue(Ensemblecoordonne.charAt(i))-1;
            if(i==Ensemblecoordonne.length()-1){
                break;
            }
            int y = Character.getNumericValue(Ensemblecoordonne.charAt(i+1))-1;
            res= res+tableau[x][y]+ " ";
        }
        //on retourne le résultat du chiffrage 
        return res;

    } //fin du chiffrement 

    //Déchiffrement 
    static String Dechiffrement(String texte) {
        //le tableau carré de polybe 6*6 
        char[][] tableau = {{'V','B','K','U','A','9'}, {'C','L','X','R','D','8'},
                            {'M','Y','S','F','N','7'},{'Z','O','G','P','I','6'},
                            {'H','Q','E','W','T','5'},{'0','1','2','3','4'},
                            };
        //res est le résultat 
        String res = "";
        //la liste des coordonnee
        ArrayList<Integer> coordonnee = new ArrayList<Integer>();
        
        //Ensemble des coordonne X des lettres
        String EnsemblecoordonneX = " ";
        //Ensemble des coordonne Y des lettres
        String EnsemblecoordonneY = " ";

        //on regarde si le texte n'est pas un multiple de 11 on rajoute 'X'
        while((texte.length()%11) !=0){
            texte=texte+'X';

        }

        //calcule des coordonnées 
        for(int i=0;i<texte.length();i++){
            char carac = texte.charAt(i);
            for(int a=0;a<tableau.length;a++){
                for(int z=0;z<tableau[a].length;z++){
                    if(carac==tableau[a][z]){
                        coordonnee.add(a+1);
                        coordonnee.add(z+1);
                        //System.out.println("lettre : "+carac+ " ligne : "+(a+1)+" colonne : "+(z+1));
                    }
                }
            }
        }

        //System.out.println();

        //blocOnze permet de découper les mots par bloc de 11
        int blocOnzeX=10;
        int z =0;
        //on parcours la liste des coordonnée pour avoir que les X
        while(z<coordonnee.size()){
            //on ajoute les X dans EnsemblecoordonneeX
            EnsemblecoordonneX=EnsemblecoordonneX+coordonnee.get(z);
            if(z==blocOnzeX){ // si on atteint notre bloc de 11 
                //on passe au bloc suivant 
                blocOnzeX=blocOnzeX+22;
                z=z+11;
            }
            z++;
        }

        int blocOnzeY=22;
        int z1 =11;
        //on parcours la liste des coordonnée pour avoir que les Y
        while(z1<coordonnee.size()){
                //System.out.print(coordonnee.get(z1));
            EnsemblecoordonneY=EnsemblecoordonneY+coordonnee.get(z1);
            if(z1==blocOnzeY){ // si on atteint notre bloc de 11 
                //on passe au bloc suivant 
                blocOnzeY=blocOnzeY+22;
                z1=z1+11;
            }
            z1++;
        }

        System.out.println("Texte Dechiffré : ");

        // on parcours Ensemblecoordonnee et ensuite on affiche en fonction du tableau de polybe 
        for(int i =1;i<EnsemblecoordonneX.length();i++){
            int x1 = Character.getNumericValue(EnsemblecoordonneX.charAt(i))-1;
            int y1 = Character.getNumericValue(EnsemblecoordonneY.charAt(i))-1;
            //System.out.print(tableau[x1][y1]+ " ");
            res= res+tableau[x1][y1]+ " ";
        }
    //on retourne le texte déchiffré 
    return res;
    
    } //fin dechiffrement 

}

//DRUETYYRGNNQQKYVTGTEDXRQILLRSI