import java.util.ArrayList;
import java.util.Scanner;

public class ChiffrementHill {
    public static void main(String []args){

        Scanner scan = new Scanner(System.in);
        String line = System.getProperty("line.separator");
        scan.useDelimiter(line);
        //afficher au lancement du programme
        System.out.println("Chiffre de Hill : ");
        System.out.println();
        System.out.print("1- Chiffrement ou  2- Déchiffrement : ");
        int option = scan.nextInt();
        switch (option) {
            case 1:
                System.out.print("Entrer le texte à chiffrer :(exemple : ELECTION ) : ");
                //String texte = scan.nextLine().toUpperCase().replace(" ", "");
                String texte = scan.next().toUpperCase().replace(" ", "");//texte contient le texte qu'on doit chiffré et on élimine les espaces

                System.out.print("Enter a:");
                int a =  Integer.parseInt(scan.next());//on récupère la valeur de a saisi 

                System.out.print("Enter b:");
                int b =  Integer.parseInt(scan.next());//on récupère la valeur de b saisi 

                System.out.print("Enter c:");
                int c =  Integer.parseInt(scan.next());//on récupère la valeur de c saisi 

                System.out.print("Enter d:");
                int d =  Integer.parseInt(scan.next());//on récupère la valeur de d saisi 

                //on applique le chiffrement avec les paramètres correspondant
                System.out.println(Chiffrement(texte,a,b,c,d));
                break;
            case 2:
                System.out.print("Entrer le texte à Déchiffré :");
                texte = scan.next().toUpperCase().replace(" ", "");//texte contient le texte qu'on doit chiffré et on élimine les espaces

                System.out.print("Enter a:");
                a =  Integer.parseInt(scan.next());//on récupère la valeur de a saisi 

                System.out.print("Enter b:");
                b =  Integer.parseInt(scan.next());//on récupère la valeur de b saisi 

                System.out.print("Enter c:");
                c =  Integer.parseInt(scan.next());//on récupère la valeur de c saisi 

                System.out.print("Enter d:");
                d =  Integer.parseInt(scan.next());//on récupère la valeur de d saisi

                //on applique le chiffrement avec les paramètres correspondant
                System.out.println(Dechiffrement(texte,a,b,c,d));
                break;
            default:
                System.out.println("Caractère invalide : choisir 1 ou 2 : ");
                System.exit(0);
                //break;
                
        }
        
    }
    
    //chiffrement 
    static String Chiffrement(String texte, int a,int b,int c,int d ) {
    int y1=0;int y2=0;//int z1=0;int z2=0;
    //numx1 est numero de chaque lettre
    int numx1=0;
    //NumeroLettre contient la liste des numéros correspondant à chaque lettre
    ArrayList<Integer> NumeroLettre = new ArrayList<Integer>();
    //CombinaisonLin contient la liste des combinaisons linéaires
    ArrayList<Integer> CombinaisonLin = new ArrayList<Integer>();
    //on regarde si la longueur du texte est impair , on ajoute un 'X' pour qu'il soit pair
    if((texte.length())%2!=0){
        texte=texte+"X";
        //System.out.println("ajout espace "+texte.length());
    }
    
    //on boucle sur le texte pour ensuite stocker les numéros de chaque lettre dans la liste NumeroLettre
    for(int i=0;i<texte.length();i++){
        numx1 = ((int)texte.charAt(i))-32;
        NumeroLettre.add(numx1);
        System.out.println("num1 : "+numx1);

    }
    //on boucle sur NumeroLettre pour ensuite appliquer la combinaison linéaire à chaque numéros
    for(int i=0;i<NumeroLettre.size();i=i+2){
        y1 = (a*NumeroLettre.get(i))+(b*(NumeroLettre.get(i+1)));
        y2 = (c*NumeroLettre.get(i))+(d*(NumeroLettre.get(i+1)));
        CombinaisonLin.add(y1);
        CombinaisonLin.add(y2);
        if(i==(NumeroLettre.size()-1)){
            break;
        }

    }
    System.out.print("Texte chiffré : " );
    //res contient le resultat du texte chiffré
    String res = "";

    //on boucle sur la CombinaisonLin pour ensuite attribué chaque combinaison à la lettre correspondant
    for(int i=0;i<CombinaisonLin.size();i++){
        int nombre = (CombinaisonLin.get(i)%95);
        res = res+(char)(nombre+32);
    }
    //on retourne le resultat
    return res;

    }//fin chiffrement 

    //Déchiffrement 
    static String Dechiffrement(String texte, int a,int b,int c,int d ) {
        //NumeroLettre contient la liste des numéros correspondant à chaque lettre
        ArrayList<Integer> NumeroLettre = new ArrayList<Integer>();
        //CombinaisonLin contient la liste des combinaisons linéaires
        ArrayList<Integer> CombinaisonLin = new ArrayList<Integer>();    
        //res contient le résultat du texte déchiffré
        String res="";
        int numx1=0;    //int numx2=0;
        int a1,b1,c1,d1;a1=0;b1=0;c1=0;d1=0;
        int y1=0;int y2=0;//int x1=0;int x2=0;
        //determinant de la matrice
        int determinant=0;
        //calcule du determinant 
        determinant = (a*d)-(c*b);
        int inversedetTemp=0;
        //on vérifie si c'est inversible ou pas
        if (determinant%5!=0||determinant%19!=0){
            inversedetTemp = modulo(determinant);
        }
        //la matrice avec d1,b1;c1,a1
        d1 = inversedetTemp*d;
        b1 = inversedetTemp*b;
        c1=inversedetTemp*c;
        a1=inversedetTemp*a;

        //on boucle sur le texte pour ensuite stocker les numéros de chaque lettre dans la liste NumeroLettre
        for(int i=0;i<texte.length();i++){
            numx1 = ((int)texte.charAt(i))-32;
            NumeroLettre.add(numx1);
    
        }

        for(int i=0;i<NumeroLettre.size();i++){
            System.out.println(NumeroLettre.get(i));
        }

         //on boucle sur NumeroLettre pour ensuite appliquer la combinaison linéaire à chaque numéros
        for(int i=0;i<NumeroLettre.size();i=i+2){
            y1 = (d1*NumeroLettre.get(i))+(-b1*(NumeroLettre.get(i+1)));
            y2 = (-c1*NumeroLettre.get(i))+(a1*(NumeroLettre.get(i+1)));
            CombinaisonLin.add(y1);
            CombinaisonLin.add(y2);
            if(i==(NumeroLettre.size()-1)){
                break;
            }
        }

        System.out.print("Texte déchiffré : " );

        //on boucle sur la CombinaisonLin pour ensuite attribué chaque combinaison à la lettre correspondant
        for(int i=0;i<CombinaisonLin.size();i++){
            int nombre = (CombinaisonLin.get(i)%95);
            res = res+(char)(nombre+32);
        }
        //on retourne le résultat 
        return res;

    }
    
//calcule de l'inverse du déterminat %95
    public static int modulo(int det){
        int i=0;
        int res=0;
        while(i<1000){
        int nombre=(det*i)%95;
        if (nombre==1){
            //System.out.println("*****************************");
            //System.out.println("valeur de i a retenir : "+i);
            //System.out.println("*****************************");
            res=i;
            break;
        }
        i=i+1;
        }
        return res;
    }

    
}

